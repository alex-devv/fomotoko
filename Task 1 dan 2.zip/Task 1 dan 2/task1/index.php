<?php
// Mengatur header untuk memberi tahu klien bahwa konten yang dikirimkan adalah JSON
header("Content-Type: application/json");

// Koneksi ke database (gantilah dengan informasi koneksi Anda)
$host = "localhost";
$username = "username";
$password = "password";
$database = "tokoonline";

$conn = new mysqli($host, $username, $password, $database);

// Memeriksa apakah koneksi ke database berhasil
if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

// Endpoint 1: Membuat pesanan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_order') {
    // Mengambil data dari permintaan POST
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Validasi stok yang mencukupi
    $check_stock_query = "SELECT quantity_in_stock FROM products WHERE product_id = $product_id";
    $result = $conn->query($check_stock_query);

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $stock = $row['quantity_in_stock'];

        if ($stock >= $quantity) {
            // Stok mencukupi, buat pesanan
            $order_date = date("Y-m-d H:i:s");
            $insert_order_query = "INSERT INTO orders (product_id, quantity_ordered, order_date) VALUES ($product_id, $quantity, '$order_date')";
            if ($conn->query($insert_order_query) === TRUE) {
                // Kurangi stok produk
                $update_stock_query = "UPDATE products SET quantity_in_stock = quantity_in_stock - $quantity WHERE product_id = $product_id";
                $conn->query($update_stock_query);
                echo json_encode(array("message" => "Pesanan berhasil dibuat."));
            } else {
                echo json_encode(array("error" => "Gagal membuat pesanan."));
            }
        } else {
            echo json_encode(array("error" => "Stok tidak mencukupi."));
        }
    } else {
        echo json_encode(array("error" => "Produk tidak ditemukan."));
    }
}

// Menutup koneksi database
$conn->close();
?>
