<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hidden Item Game</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    <style>
        .table-cell {
            width: 40px;
            height: 40px;
            text-align: center;
            vertical-align: middle;
            font-size: 18px;
        }

        .bg-obstacle {
            background-color: #000;
            color: #fff;
        }

        .bg-clear {
            background-color: #fff;
        }

        .bg-player {
            background-color: #007bff;
            color: #fff;
        }

        .bg-possible-item {
            background-color: #28a745;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="my-4">Hidden Item Game</h1>
        <?php
        // Fungsi untuk mencari koordinat yang mungkin untuk item
        function findPossibleItemLocations($grid, $playerRow, $playerCol, $upSteps, $rightSteps, $downSteps) {
            $possibleLocations = [];

            for ($i = 1; $i <= $upSteps; $i++) {
                $row = $playerRow - $i;
                if ($row >= 0 && $grid[$row][$playerCol] === '.') {
                    $possibleLocations[] = [$row, $playerCol];
                }
            }

            for ($i = 1; $i <= $rightSteps; $i++) {
                $col = $playerCol + $i;
                if ($col < strlen($grid[0]) && $grid[$playerRow][$col] === '.') {
                    $possibleLocations[] = [$playerRow, $col];
                }
            }

            for ($i = 1; $i <= $downSteps; $i++) {
                $row = $playerRow + $i;
                if ($row < count($grid) && $grid[$row][$playerCol] === '.') {
                    $possibleLocations[] = [$row, $playerCol];
                }
            }

            return $possibleLocations;
        }

        // Fungsi untuk mencetak grid dengan item yang mungkin
        function printGridWithPossibleItem($grid, $possibleItemLocation) {
            echo '<table class="table table-bordered">';
            foreach ($grid as $rowIndex => $row) {
                echo '<tr>';
                foreach (str_split($row) as $colIndex => $cell) {
                    $classes = 'table-cell ';
                    if ($cell === '#') {
                        $classes .= 'bg-obstacle';
                    } elseif ($cell === '.') {
                        $classes .= 'bg-clear';
                    } elseif ($cell === 'X') {
                        $classes .= 'bg-player';
                    }
                    if ($rowIndex === $possibleItemLocation[0] && $colIndex === $possibleItemLocation[1]) {
                        $classes .= ' bg-possible-item';
                        $cell = '$'; // Tandai lokasi item dengan simbol $
                    }
                    echo '<td class="' . $classes . '">' . $cell . '</td>';
                }
                echo '</tr>';
            }
            echo '</table>';

            // Deskripsi di bawah tabel
            echo '<p><strong>Deskripsi:</strong></p>';
            echo '<ol>';
            echo '<li>".": Melambangkan jalan yang jelas.</li>';
            echo '<li>"X": Mewakili posisi awal pemain.</li>';
            echo '<li>"$": Kemungkinan lokasi item yang harus ditemukan pemain.</li>';
        }

        $grids = [
            [
                "########",
                "#......#",
                "#.###..#",
                "#...#.##",
                "#X#....#",
                "########"
            ]
        ];

        // Aturan permainan
        $upSteps = 1;
        $rightSteps = 2;
        $downSteps = 3;

        foreach ($grids as $grid) {
            // Temukan posisi awal pemain (X)
            foreach ($grid as $rowIndex => $row) {
                $colIndex = strpos($row, 'X');
                if ($colIndex !== false) {
                    $playerRow = $rowIndex;
                    $playerCol = $colIndex;
                    break;
                }
            }

            // Temukan koordinat yang mungkin untuk item (acak)
            $possibleItemLocations = [];
            while (empty($possibleItemLocations)) {
                $randomRow = mt_rand(0, count($grid) - 1);
                $randomCol = mt_rand(0, strlen($grid[0]) - 1);
                if ($grid[$randomRow][$randomCol] === '.') {
                    $possibleItemLocations[] = [$randomRow, $randomCol];
                }
            }

            echo "<h2>Grid:</h2>";
            printGridWithPossibleItem($grid, $possibleItemLocations[0]);
        }
        ?>
    </div>
</body>
</html>
